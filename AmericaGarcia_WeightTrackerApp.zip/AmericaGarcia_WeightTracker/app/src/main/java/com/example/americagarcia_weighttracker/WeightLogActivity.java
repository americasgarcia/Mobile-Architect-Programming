package com.example.americagarcia_weighttracker;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.database.Cursor;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class WeightLogActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    EditText editWeight;
    Button btnAddWeight;
    TextView textEncouragement;
    TableLayout table;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_log);

        dbHelper = new DatabaseHelper(this);
        editWeight = findViewById(R.id.editWeight);
        btnAddWeight = findViewById(R.id.btnAddWeight);
        textEncouragement = findViewById(R.id.textEncouragement);
        table = findViewById(R.id.tableWeightLog);

        btnAddWeight.setOnClickListener(v -> {
            String weight = editWeight.getText().toString();
            String date = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(new Date());
            if (dbHelper.addWeight(weight, date)) {
                Toast.makeText(this, "Weight added!", Toast.LENGTH_SHORT).show();
                showWeights();
                updateEncouragement();
            } else {
                Toast.makeText(this, "Error saving weight", Toast.LENGTH_SHORT).show();
            }
        });

        showWeights();
        updateEncouragement();
    }

    private void showWeights() {
        table.removeViews(1, Math.max(0, table.getChildCount() - 1));
        Cursor cursor = dbHelper.getAllWeights();

        if (cursor.moveToFirst()) {
            do {
                TableRow row = new TableRow(this);
                TextView date = new TextView(this);
                TextView weight = new TextView(this);

                date.setText(cursor.getString(2));
                weight.setText(cursor.getString(1));

                row.addView(date);
                row.addView(weight);
                table.addView(row);
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    private void updateEncouragement() {
        Cursor cursor = dbHelper.getAllWeights();
        int count = cursor.getCount();

        if (count == 0) {
            textEncouragement.setText("Let’s start tracking your progress today!");
        } else if (count < 5) {
            textEncouragement.setText("Nice work! Keep going, you’re close to reaching your goal");
        } else if (count < 10) {
            textEncouragement.setText("You’re staying consistent, this is where results happen!");
        } else {
            textEncouragement.setText("Amazing dedication! You’ve made great progress!");
        }
        cursor.close();
    }
}
